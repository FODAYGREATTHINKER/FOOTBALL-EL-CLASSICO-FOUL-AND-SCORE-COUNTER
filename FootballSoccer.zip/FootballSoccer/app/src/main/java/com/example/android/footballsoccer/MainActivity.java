package com.example.android.footballsoccer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int foul = 0;
    int score = 0;
    int scoreMadrid =0;
    int foulMadrid = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * THIS LINE IS USED TO CALL BARCA SCORE METHOD
     **/
    public void increaseScore(View view) {
        score = score + 1;
        displayBarcaScore(score);
    }

    /**
     * THIS LINE IS USED TO CALL BARCA FOUL METHOD
     **/
    public void increaseBarcaFoul(View view) {
        foul = foul + 1;
        displayBarcaFoul(foul);
    }

    /**
     * THIS METHOD IS USED FOR BARCA SCORE
     **/
    public void displayBarcaScore(int score) {
        TextView scoreView = (TextView) findViewById(R.id.barca_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * THIS METHOD IS USED FOR THE AMOUNT OF BARCA FOUL
     **/
    public void displayBarcaFoul(int foul) {
        TextView foulView = (TextView) findViewById(R.id.barca_foul);
        foulView.setText(String.valueOf(foul));
    }


    /**

     THIS TEAM REAL MADRID SECTION
     **/


    /**
     * THIS LINE IS USED TO CALL MADRID SCORE METHOD
     **/
    public void increaseMadridScore(View view) {
        scoreMadrid = scoreMadrid + 1;
        displayMadridScore(scoreMadrid);
    }

    /**
     * THIS LINE IS USED TO CALL MADRID FOUL METHOD
     **/

    public void increaseMadridFoul(View view) {
        foulMadrid = foulMadrid + 1;
        displayMadridFoul(foulMadrid);
    }

    /**
     * THIS METHOD IS USED FOR MADRID SCORE
     **/
    public void displayMadridScore(int score) {
        TextView scoreView = (TextView) findViewById(R.id.madrid_Score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * THIS METHOD IS USED FOR MADRID FOUL
     **/
    public void displayMadridFoul(int foul) {
        TextView foulView = (TextView) findViewById(R.id.madrid_foul);
        foulView.setText(String.valueOf(foul));
    }

    /**
     * THIS IS THE RESET BUTTON ACTION
     **/
    public void resetFoul(View view) {
        score = 0;
        displayBarcaScore(score);
        displayMadridScore(score);

    }

    public void resetAll(View view) {
        foul = 0;
        displayBarcaFoul(foul);
        displayMadridFoul(foul);
    }
}
